#This is my README
ECS 175: Computer Graphics
UC Davis, Spring 2013
Assignment3

Stefan Peterson
stpeterson@ucdavis.edu
998556530

Requirements:
GLUT
OpenGL
C++
cmake 

cd ..

Commands to create makefile + compile + run:

make
./vase

Controls:
zoom:
z - zoom in
x - zoom out
scrollwheel - zoom in / zoom out

translate:
left arrow - translate left 
right arrow - translate right
up arrow - translate up
down arrow - translate down

rotate:
w - rotate up
a - rotate left
s - rotate down
d - rotate right
mouse drag - rotate up/down/left/right


